# Done

* proof-read other peers report.
* Fixed the proportions in both the price model and the bitcoin amount in the simulation.
* Wrote the piece on shortest pats for different graph models. 
* Fixed the notes received from peer review.

# Problem

Starting to be ready to start generating results.


# Do

* Defining games that may be of interest for report.
* Start simulating.


