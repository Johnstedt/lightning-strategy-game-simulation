# Done

* Got a simulation up and running in java with Dijkstra.
* Finish the macroeconomics part.
* Sent email to Game Theory person for meeting.
* Found rpickhardt previous work and played with it.
* Finally got a way to run clightning from the Cinnober office.
* Wrote the two first pages of the bitcoin segment.


# Problem 

Its seem to much more of a graph problem than I first realized rather than 
a game theory problem. One thing I definitely need to figure out is 
how I want to graph the network both for simulation but also for implementation.

Python works good for cligthing, but isn't it better to do it in C then if 
there is a interface already in clightning. 

If there is a good one for java like there is in Python one should shift directly
now. 

# Do

* Continue on the bitcoin segment, maybe switch between that and
the scaling segment to save on saneness.
* Figure out which graph framework to use both for simulation and for
implementation. 
* Meta-language for simulation.
* Algorithms and heuristics. Does it need to be in background(?)       
