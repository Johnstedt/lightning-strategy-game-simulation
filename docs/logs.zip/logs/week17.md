# Done

* Did the last simulations.
* Getting good structure on the result section.
* Fixing abstract one last time.
* Fixing acknowledgement one last time.
* Retrieved comments from proof-read. Send away again for proof-read.

# Problem

Getting red line through report. Need to fix the images too from simluation, i.e paint job incoming.

# Do 

* Finish report
* Start presentation.