
# Done

* Implemented timing aggressiveness. Both linear and exponential from middle. 
* Implemented funding strategy.
* Implemented allocation strategy.
* Implemented anti-barabasi attachment function.
* Implemented hassan et. al. attachment function.

* Started rebalance code on real network.
* Plugin pull request fix.

# Problem

Seem to be going to done with most things sufficiently to have good margin. Have created a list with everything
left implementation wise. Will most likely have finished most of it next week. Will be interesting to see what happens
with pull request and what I can contribute with.

# Do

* Private nodes
* Robustness
* Shortest path
* Scaling bitcoin chapter
