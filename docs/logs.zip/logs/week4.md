# Done

* Chosen environment, use networkx and python for both and a deployable unit on top of c-lightning. 
* Got Scale free measurements working and plot with matlibplot from any graph
* The first simulation strategies with preferential attachment is done
* 2 More pages on the bitcoin chapter
* Read more papers on graphs than a sane person should.

# Problem

The graphing part of the problem may be larger chunk than anticipated. Which might not be to
devastating since it may solve the problems many perceived problems. Betweenness Centrality is a good 
measurement. How exactly to draw conclusions from the eventual simulation may prove a problem.


# Do

* Meet with Lars-Daniel Öhman with ideas over graph
* Finish bitcoin chapter and shift focus Lightning.
* Get first simulation going.