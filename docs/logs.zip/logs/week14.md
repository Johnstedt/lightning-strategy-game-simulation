# Done

* Did the plots for the measurements in the graph.
* Made the code more standardize to handle large quantity of simulated data without losing structure.
* Held simulation to get proper form.
* Started creating JSON with reasonable values to simulate.

# Problem

The amount of variations in the simulation is large. The simulations take quite a while to run. 
Would be better if everything was proper before the simulations are run. Started setting the variables
and started testing simulations, will need more tuning.

# Do

* Do more of the metrics after simulation, like wealth distribution and so on.