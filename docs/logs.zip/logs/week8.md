# Done
* Plot survival history
* Plot averages of survival histories.
* Plot box plot of survival histories. 
* Plot degree distribution for traditional topology models.
* Read chapter 6 and most of 7 NCM.
* Some basic open, close policies.
* Started on the hell that is optimal edge price function with a cost function instead of one dimensional price.

# Problem

The pricing function proves quite a challenge, will be solvable with quite a brutal time complexity.
Good meeting with Oskar on how to create a model out of a optimal price. 

I think how I may reach decent results.

Only need a decent model first and then tweak around with the rest strategies.

# Do

* Meet Eddie Walbro discuss model.
* Convert optimal price curve to cost function.
* Make simulation more abstract to make config json actually work.