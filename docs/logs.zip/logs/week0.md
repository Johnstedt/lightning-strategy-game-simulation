# Week 0 | * - 20-01-2019  

## Done

* Read the bitcoin whitepaper. 
* Read mastering bitcoin.
* Read the hashcash whitepaper.

* Set up a bitcoin full node @ home.
* Created this repository with a thesis template received from Niklas Fries.

## Problems

I know very little and need to know more to be able to
take any good decision.

## Do 

* Read the lightning whitepaper.
* Create a time scheme.
* Fill in planning.
* Set up at Cinnober.

* Read as much as possible.

* Start writing already known parts of the report
 such as core bitcoin mechanics, alternative scaling solutions etc.

 * Test out ln software both for mainnet and testnet.
