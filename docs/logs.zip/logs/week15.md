# Done

* Did the wealh distribution plot for all sim.
* Calculate the quota and write to file.
* Evalutation chapter getting closer.
* A bit on discussion. 

# Problem

Still trouble finding satisfying simulations, will test more next week and continue report.

# Do

* Config more simulations
* Run more simulations