
# Done

* Implemented private/non advertised node option.
* Finished scaling Bitcoin chapter.
* Finished mixture problem.
* Wrote piece on non advertised nodes.
* Robustness implemented, validated on mainnet.
* Shortest path metric implemented
* Fixed report for peer review

# Problem

Finished most necessary for simulation. Will add a few extra things and then start generating results.
Will have a meeting next friday discussing interesting setups to try simulating.

# Do

* Reed others peer review.
* Fix the feedback I will receive.
* Fix proportions.
* Add mixing strategies.