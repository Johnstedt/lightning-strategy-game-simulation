# Done

* Converted fields to a probability model, abstracted to use in simulation.
* Play price model against random with large success.
* Abstracted the simulation so only the meta-fields need change. 
* Implemented timing category and a couple strategies.
* Balance section in discussion done, or close to.
* Mirror appendix structure figured out.
* Started strategy appendix.

# Problem

It really starts to take shape. Timing, funding, allocation strategies are all simple in relation.
Might finish all implementations next week to give time to avg shortest path, robustness analysis etc
the week after. 
 
Report is in good shape. 

Need a strong implementation these next couple of weeks so result section may start 2/3 into the thesis.
 
# Do

* Implement timing aggressiveness. 
* Implement funding strategy.
* Implement allocation strategy.
* Start look at real implementation, move to use strategies testnet/mainnet.
