# Done

* Did more simulations.
* Find simulations with interesting ideas.
* More text in report, evaluation done.
* Did send early draft for proof-read.

# Problem

Did some more simulations, most basic things covered though.
Need to finish all the chapter so as to send for proof read.

# Do

* Finish report for proof-read.
* Do more simulations.