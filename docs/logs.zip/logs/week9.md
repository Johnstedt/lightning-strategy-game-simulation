# Done

* Fixed a few errors in report
* Decent plots and equations for scale free network as well as degree distribution for real network.
* Met Eddie Walbro
* Got a three dimensional plot over price agenda field. 
* Got simulation a bit more modular

# Problem

To get all the points to feasible scale may take some time. 
However the price model will work, maybe not perfect but perfect enough to move on.
Will return if time.

Need to streamline the simulation, a lot is hardcoded for random and matthews.

Report is getting better each week, need to start on the ending parts, appendixes and EGT. 

# Do

* Convert field to normalized probabilities.
* Test price model against random
* Continue abstracting model.
* implement bias over same model.
