# Week 1 | 21-01-2019 - 27-01-2019  

## Done

* Wrote the risk segment and finnish the project plan, handed it in and got it accepted.
* Sent away nine emails to various people in the space with deep knowledge of the space.
* Received answer from Christian Decker, maintainer of c-lightning.
* Wrote almost all of macroeconomics.
* Set up lnd. 

## Problems

There is still many unknowns in both the ln network and in game theory.
Continue reading whilst getting the fundamental pieces in report as I learn them
is probably a good strategy.

## Do 

* Get the most fundamental om test cases down in java code.
* Graph it.
* Finish the macroeconomics part.
* Meet or plan meet game theory guru.
