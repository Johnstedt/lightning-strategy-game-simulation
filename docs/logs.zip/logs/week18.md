# Done

* Monday and Tuesday, fix all the details with the report.
* Starting preparing the presentation.

# Problem

Not anymore, may be difficult to get something comprehensible under 30 minutes.

# Do

* Finish the presentation.
* Do the presentation.
* Do the opposition.